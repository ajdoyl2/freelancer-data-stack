from dagster._core.storage.event_log.sqlite.consolidated_sqlite_event_log import (
    ConsolidatedSqliteEventLogStorage as ConsolidatedSqliteEventLogStorage,
)
from dagster._core.storage.event_log.sqlite.sqlite_event_log import (
    SqliteEventLogStorage as SqliteEventLogStorage,
)
