from dagster._cli.workspace.cli_target import (
    get_workspace_process_context_from_kwargs as get_workspace_process_context_from_kwargs,
    workspace_target_argument as workspace_target_argument,
)
