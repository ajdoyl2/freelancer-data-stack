import dagster._check as check
from dagster._builtins import Bool, Float, Int, String
from dagster._core.types.dagster_type import (
    Any as RuntimeAny,
    List,
)
from dagster._core.types.python_dict import PythonDict
from dagster._core.types.python_set import PythonSet
from dagster._core.types.python_tuple import PythonTuple

# Type-ignores below are due to mypy bug tracking names imported from module's named "types".
SUPPORTED_RUNTIME_BUILTINS = {
    int: Int,
    float: Float,
    bool: Bool,
    str: String,
    list: List(RuntimeAny),
    tuple: PythonTuple,
    set: PythonSet,
    dict: PythonDict,
}


def is_supported_runtime_python_builtin(ttype):
    return ttype in SUPPORTED_RUNTIME_BUILTINS


def remap_python_builtin_for_runtime(ttype):
    """This function remaps a python type to a Dagster type, or passes it through if it cannot be
    remapped.
    """
    from dagster._core.types.dagster_type import resolve_dagster_type

    check.param_invariant(is_supported_runtime_python_builtin(ttype), "ttype")

    return resolve_dagster_type(SUPPORTED_RUNTIME_BUILTINS[ttype])
