"""Standard Rules packaged with sqlfluff."""
